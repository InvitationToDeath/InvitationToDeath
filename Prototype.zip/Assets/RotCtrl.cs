﻿using UnityEngine;
using System.Collections;

public class RotCtrl : MonoBehaviour {

    
	
	// Update is called once per frame
    void Update()
    {
        //if (gameObject.transform.eulerAngles.z % 180 < 180)
        if (gameObject.transform.eulerAngles.x % 180 != 90) //90도가 아니면 90도가 될때까지 복원
        {
            gameObject.transform.Rotate(gameObject.transform.forward, (90 - gameObject.transform.eulerAngles.x % 180) / 100);
        }
    }
}